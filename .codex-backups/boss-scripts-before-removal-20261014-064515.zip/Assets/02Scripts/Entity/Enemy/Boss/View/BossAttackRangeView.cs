using UnityEngine;

namespace Alpha.Boss
{
    // 공격별 Targeting 거리와 AttackArea를 Scene 뷰에 표시한다.
    [DisallowMultipleComponent]
    public sealed class BossAttackRangeView : MonoBehaviour
    {
        private const int ArcSegments = 64;

        [Header("Attack1 Preview")]
        [SerializeField] private bool _showAttack1Targeting = true;
        [SerializeField] private bool _showAttack1Area = true;
        [SerializeField] private Color _attack1Color = new(1f, 0.38f, 0.12f);

        [Header("Attack2 Area Preview")]
        [SerializeField] private Color _attack2Color = new(0.1f, 0.7f, 1f);
        [SerializeField] private bool _showAttack2Preview;

        [Header("Attack5 Preview")]
        [SerializeField] private bool _showAttack5Targeting = true;
        [SerializeField] private bool _showAttack5Area = true;
        [SerializeField] private Color _attack5Color = new(1f, 0.24f, 0.6f);

        private void OnDrawGizmosSelected()
        {
            BossCore core = GetComponentInParent<BossCore>();
            BossCombatFlow combat = GetComponentInParent<BossCombatFlow>();
            if (combat == null)
                return;

            Transform bossOrigin = core != null ? core.transform : combat.transform;

            DrawAttackPreview(combat, EBossAttackType.Attack1,
                bossOrigin, _showAttack1Targeting, _showAttack1Area,
                _attack1Color);
            DrawAttackPreview(combat, EBossAttackType.Attack5,
                bossOrigin, _showAttack5Targeting, _showAttack5Area,
                _attack5Color);

            if (_showAttack2Preview)
                DrawAttack2Preview(core,
                    GetArea(combat, EBossAttackType.Attack2));
        }

        private static void DrawAttackPreview(
            BossCombatFlow p_combat, EBossAttackType p_type,
            Transform p_bossOrigin, bool p_showTargeting,
            bool p_showArea, Color p_color)
        {
            if (p_showTargeting)
                DrawTargetingRange(p_combat, p_type,
                    p_bossOrigin.position, p_color);

            if (!p_showArea)
                return;

            BossAttackAreaSettings area = GetArea(p_combat, p_type);
            Transform areaOrigin = area?.Origin != null
                ? area.Origin
                : p_bossOrigin;
            DrawArea(area, areaOrigin, p_color);
        }

        private static BossAttackAreaSettings GetArea(
            BossCombatFlow p_combat, EBossAttackType p_type)
        {
            return p_combat.TryGetAttackData(p_type,
                out BossAttackData.AttackEntry data)
                ? data.Area
                : null;
        }

        private void DrawAttack2Preview(
            BossCore p_core, BossAttackAreaSettings p_area)
        {
            // 공격 중에는 기록된 지점을 표시해 이펙트 위치와 일치시킨다.
            if (Application.isPlaying && p_core != null &&
                p_core.TryGetAttack2TargetPose(
                    out Vector3 targetPosition,
                    out Quaternion targetRotation))
            {
                DrawArea(p_area, targetPosition,
                    targetRotation, _attack2Color);
                return;
            }

            Transform attack2Origin = Application.isPlaying &&
                                      p_core != null && p_core.Target != null
                ? p_core.Target
                : p_area?.Origin;
            DrawArea(p_area, attack2Origin, _attack2Color);
        }

        private static void DrawTargetingRange(
            BossCombatFlow p_combat, EBossAttackType p_type,
            Vector3 p_bossPosition, Color p_color)
        {
            if (!p_combat.TryGetTargetingRange(p_type,
                    out float minDistance, out float maxDistance) ||
                maxDistance <= 0f)
            {
                return;
            }

            Color previousColor = Gizmos.color;
            Matrix4x4 previousMatrix = Gizmos.matrix;
            Gizmos.color = p_color;
            BoxCollider bodyCollider = p_combat.BodyCollider;
            if (bodyCollider != null && bodyCollider.enabled)
            {
                Gizmos.matrix = bodyCollider.transform.localToWorldMatrix;
                Vector3 center = bodyCollider.center;
                center.y -= bodyCollider.size.y * 0.5f - 0.1f;
                Vector2 halfSize = new(bodyCollider.size.x * 0.5f,
                    bodyCollider.size.z * 0.5f);

                if (minDistance > 0f &&
                    !Mathf.Approximately(minDistance, maxDistance))
                {
                    DrawBoxDistance(center, halfSize, minDistance);
                }

                DrawBoxDistance(center, halfSize, maxDistance);
            }
            else
            {
                Gizmos.matrix = Matrix4x4.identity;
                Vector3 center = p_bossPosition + Vector3.up * 0.1f;

                if (minDistance > 0f &&
                    !Mathf.Approximately(minDistance, maxDistance))
                {
                    DrawArc(center, minDistance, 0f, 360f, true);
                }

                DrawArc(center, maxDistance, 0f, 360f, true);
            }

            Gizmos.matrix = previousMatrix;
            Gizmos.color = previousColor;
        }

        // Collider 표면에서 일정 거리만큼 떨어진 둥근 사각형을 그린다.
        private static void DrawBoxDistance(Vector3 p_center,
            Vector2 p_halfSize, float p_distance)
        {
            float left = p_center.x - p_halfSize.x;
            float right = p_center.x + p_halfSize.x;
            float back = p_center.z - p_halfSize.y;
            float front = p_center.z + p_halfSize.y;

            DrawDashedLine(new Vector3(left, p_center.y, back - p_distance),
                new Vector3(right, p_center.y, back - p_distance));
            DrawDashedLine(new Vector3(left, p_center.y, front + p_distance),
                new Vector3(right, p_center.y, front + p_distance));
            DrawDashedLine(new Vector3(left - p_distance, p_center.y, back),
                new Vector3(left - p_distance, p_center.y, front));
            DrawDashedLine(new Vector3(right + p_distance, p_center.y, back),
                new Vector3(right + p_distance, p_center.y, front));

            DrawArc(new Vector3(right, p_center.y, front),
                p_distance, 0f, 90f, true);
            DrawArc(new Vector3(right, p_center.y, back),
                p_distance, 90f, 180f, true);
            DrawArc(new Vector3(left, p_center.y, back),
                p_distance, 180f, 270f, true);
            DrawArc(new Vector3(left, p_center.y, front),
                p_distance, 270f, 360f, true);
        }

        private static void DrawDashedLine(Vector3 p_start, Vector3 p_end)
        {
            const int segments = 16;
            for (int index = 0; index < segments; index += 2)
            {
                Gizmos.DrawLine(
                    Vector3.Lerp(p_start, p_end, index / (float)segments),
                    Vector3.Lerp(p_start, p_end,
                        (index + 1) / (float)segments));
            }
        }

        private static void DrawArea(
            BossAttackAreaSettings p_settings,
            Transform p_origin,
            Color p_color)
        {
            if (p_origin == null)
                return;

            DrawArea(p_settings, p_origin.position, p_origin.rotation, p_color);
        }

        private static void DrawArea(
            BossAttackAreaSettings p_settings,
            Vector3 p_originPosition,
            Quaternion p_originRotation,
            Color p_color)
        {
            if (p_settings == null || !p_settings.IsValid)
                return;

            p_settings.GetWorldPose(p_originPosition, p_originRotation,
                out Vector3 position, out Quaternion rotation);

            Matrix4x4 previousMatrix = Gizmos.matrix;
            Color previousColor = Gizmos.color;
            Gizmos.matrix = Matrix4x4.TRS(position, rotation, Vector3.one);
            Gizmos.color = p_color;

            switch (p_settings.Shape)
            {
                case EBossAttackAreaShape.Box:
                    Gizmos.DrawWireCube(
                        Vector3.forward * (p_settings.Length * 0.5f),
                        new Vector3(p_settings.Width, p_settings.Height,
                            p_settings.Length));
                    break;

                case EBossAttackAreaShape.Sector:
                    DrawSector(p_settings.Radius, p_settings.Angle,
                        p_settings.Height);
                    break;

                case EBossAttackAreaShape.Sphere:
                    Gizmos.DrawWireSphere(Vector3.zero, p_settings.Radius);
                    break;
            }

            float forwardLength = p_settings.Shape == EBossAttackAreaShape.Box
                ? p_settings.Length
                : p_settings.Radius;
            DrawForwardArrow(forwardLength);

            Gizmos.matrix = previousMatrix;
            Gizmos.color = previousColor;
        }

        private static void DrawSector(float p_radius, float p_angle,
            float p_height)
        {
            if (p_angle >= 360f)
            {
                DrawRadial(p_radius, p_height);
                return;
            }

            float halfHeight = p_height * 0.5f;
            float halfAngle = p_angle * 0.5f;
            Vector3 bottom = Vector3.down * halfHeight;
            Vector3 top = Vector3.up * halfHeight;

            DrawArc(bottom, p_radius, -halfAngle, halfAngle);
            DrawArc(top, p_radius, -halfAngle, halfAngle);

            Vector3 left = Quaternion.Euler(0f, -halfAngle, 0f) *
                           Vector3.forward * p_radius;
            Vector3 right = Quaternion.Euler(0f, halfAngle, 0f) *
                            Vector3.forward * p_radius;
            Gizmos.DrawLine(bottom, bottom + left);
            Gizmos.DrawLine(bottom, bottom + right);
            Gizmos.DrawLine(top, top + left);
            Gizmos.DrawLine(top, top + right);
            Gizmos.DrawLine(bottom, top);
            Gizmos.DrawLine(bottom + left, top + left);
            Gizmos.DrawLine(bottom + right, top + right);
        }

        private static void DrawRadial(float p_radius, float p_height)
        {
            float halfHeight = p_height * 0.5f;
            Vector3 bottom = Vector3.down * halfHeight;
            Vector3 top = Vector3.up * halfHeight;
            DrawArc(bottom, p_radius, 0f, 360f);
            DrawArc(top, p_radius, 0f, 360f);

            Gizmos.DrawLine(bottom + Vector3.forward * p_radius,
                top + Vector3.forward * p_radius);
            Gizmos.DrawLine(bottom - Vector3.forward * p_radius,
                top - Vector3.forward * p_radius);
            Gizmos.DrawLine(bottom + Vector3.right * p_radius,
                top + Vector3.right * p_radius);
            Gizmos.DrawLine(bottom - Vector3.right * p_radius,
                top - Vector3.right * p_radius);
        }

        private static void DrawArc(Vector3 p_center, float p_radius,
            float p_startAngle, float p_endAngle,
            bool p_dashed = false)
        {
            Vector3 previous = p_center +
                Quaternion.Euler(0f, p_startAngle, 0f) *
                Vector3.forward * p_radius;

            for (int index = 1; index <= ArcSegments; index++)
            {
                float angle = Mathf.Lerp(p_startAngle, p_endAngle,
                    index / (float)ArcSegments);
                Vector3 next = p_center +
                    Quaternion.Euler(0f, angle, 0f) *
                    Vector3.forward * p_radius;
                if (!p_dashed || index % 2 == 0)
                    Gizmos.DrawLine(previous, next);
                previous = next;
            }
        }

        private static void DrawForwardArrow(float p_length)
        {
            float length = Mathf.Max(0.5f, p_length);
            float head = Mathf.Min(0.3f, length * 0.2f);
            Vector3 tip = Vector3.forward * length;
            Gizmos.DrawLine(Vector3.zero, tip);
            Gizmos.DrawLine(tip, tip - Vector3.forward * head +
                Vector3.right * head * 0.5f);
            Gizmos.DrawLine(tip, tip - Vector3.forward * head -
                Vector3.right * head * 0.5f);
        }
    }
}

using System.Collections.Generic;
using UnityEngine;

namespace Alpha.Boss
{
    // 보스 공격의 단발 파티클 표현을 담당한다.
    [DisallowMultipleComponent]
    public sealed class BossAttackEffectView : MonoBehaviour
    {
        private sealed class ActiveEffect
        {
            public BossAttackData.EffectData Data;
            public GameObject Instance;
            public bool Processed;
        }

        private readonly List<ActiveEffect> _currentEffects = new();
        private readonly List<GameObject> _liveInstances = new();
        private bool _hasActiveAttack;
        private bool _spawnAtWorld;
        private Vector3 _worldPosition;
        private float _currentTimingScale = 1f;

        public bool BeginAttack(BossAttackData.AttackEntry p_attack)
        {
            return BeginAttackInternal(p_attack, false, default);
        }

        // Attack2처럼 기록된 지면 위치에 생성하고 각 Anchor의 방향을 사용한다.
        public bool BeginAttackAtWorld(BossAttackData.AttackEntry p_attack,
            Vector3 p_worldPosition)
        {
            return BeginAttackInternal(p_attack, true, p_worldPosition);
        }

        public void AdvanceAttack(float p_elapsedSeconds)
        {
            if (!_hasActiveAttack)
                return;

            float elapsed = Mathf.Max(0f, p_elapsedSeconds);
            PruneDestroyedInstances();

            for (int index = 0; index < _currentEffects.Count; index++)
            {
                ActiveEffect active = _currentEffects[index];
                if (active.Processed)
                    continue;

                BossAttackData.EffectData data = active.Data;
                if (data.EffectPrefab == null ||
                    data.Anchor == null ||
                    data.Parent == null ||
                    data.StartTimeSeconds < 0f ||
                    data.DurationSeconds <= 0f)
                {
                    active.Processed = true;
                    continue;
                }

                if (elapsed < data.StartTimeSeconds * _currentTimingScale)
                    continue;

                active.Processed = true;
                active.Instance = Spawn(data);
                if (active.Instance == null)
                    continue;

                _liveInstances.Add(active.Instance);
                Destroy(active.Instance, data.DurationSeconds);
            }
        }

        // 취소 시 즉시 제거하고, 정상 완료 시 각 이펙트의 지속시간까지 유지한다.
        public void EndAttack(bool p_completed)
        {
            if (!p_completed)
            {
                for (int index = 0; index < _currentEffects.Count; index++)
                {
                    GameObject instance = _currentEffects[index].Instance;
                    if (instance != null)
                    {
                        StopAndDestroy(instance);
                        _liveInstances.Remove(instance);
                    }
                }
            }

            _currentEffects.Clear();
            _hasActiveAttack = false;
        }

        private bool BeginAttackInternal(BossAttackData.AttackEntry p_attack,
            bool p_spawnAtWorld, Vector3 p_worldPosition)
        {
            EndAttack(false);
            PruneDestroyedInstances();
            if (p_attack == null)
                return false;

            _spawnAtWorld = p_spawnAtWorld;
            _worldPosition = p_worldPosition;
            _currentTimingScale = p_attack.TimingScale;
            IReadOnlyList<BossAttackData.EffectData> effects = p_attack.Effects;
            if (effects != null)
            {
                for (int index = 0; index < effects.Count; index++)
                    _currentEffects.Add(new ActiveEffect { Data = effects[index] });
            }

            _hasActiveAttack = true;
            return true;
        }

        private GameObject Spawn(BossAttackData.EffectData p_data)
        {
            // Anchor는 생성 위치·회전을, Parent는 생성 후 계층을 결정한다.
            Vector3 position = _spawnAtWorld
                ? _worldPosition
                : p_data.Anchor.position;
            GameObject instance = Instantiate(p_data.EffectPrefab,
                p_data.Parent, false);
            instance.transform.SetPositionAndRotation(
                position, p_data.Anchor.rotation);

            PlayParticles(instance);
            return instance;
        }

        private static void PlayParticles(GameObject p_instance)
        {
            ParticleSystem[] particles =
                p_instance.GetComponentsInChildren<ParticleSystem>(true);

            for (int index = 0; index < particles.Length; index++)
            {
                ParticleSystem particle = particles[index];
                ParticleSystem.MainModule main = particle.main;
                main.loop = false;
                particle.Stop(false,
                    ParticleSystemStopBehavior.StopEmittingAndClear);
            }

            for (int index = 0; index < particles.Length; index++)
                particles[index].Play(false);
        }

        private static void StopAndDestroy(GameObject p_instance)
        {
            if (p_instance == null)
                return;

            p_instance.SetActive(false);
            Destroy(p_instance);
        }

        private void PruneDestroyedInstances()
        {
            _liveInstances.RemoveAll(instance => instance == null);
        }

        private void OnDisable()
        {
            CleanAllEffects();
        }

        private void OnDestroy()
        {
            CleanAllEffects();
        }

        private void CleanAllEffects()
        {
            for (int index = 0; index < _liveInstances.Count; index++)
                StopAndDestroy(_liveInstances[index]);

            _liveInstances.Clear();
            _currentEffects.Clear();
            _hasActiveAttack = false;
        }

    }
}

using System;
using System.Collections.Generic;
using UnityEngine;

namespace Alpha.Boss
{
    // Animator 재생과 공격 클립의 경과 시간만 Unity 표현으로 알린다.
    [DisallowMultipleComponent]
    public sealed class BossAnimationView : MonoBehaviour
    {
        private const int BaseLayer = 0;

        private static readonly int IdleState =
            Animator.StringToHash("Base Layer.Idle");
        private static readonly int ChaseState =
            Animator.StringToHash("Base Layer.Chase");
        private static readonly int Attack1State =
            Animator.StringToHash("Base Layer.Attack1");
        private static readonly int Attack2State =
            Animator.StringToHash("Base Layer.Attack2");
        private static readonly int Attack3State =
            Animator.StringToHash("Base Layer.Attack3");
        private static readonly int Attack4State =
            Animator.StringToHash("Base Layer.Attack4");
        private static readonly int Attack5State =
            Animator.StringToHash("Base Layer.Attack5");
        private static readonly int Attack6State =
            Animator.StringToHash("Base Layer.Attack6");
        private static readonly int ProvokesState =
            Animator.StringToHash("Base Layer.Provokes");

        [SerializeField]
        private Animator _animator;

        [SerializeField, Min(0f)]
        private float _crossFadeDuration = 0.05f;

        private readonly HashSet<int> _missingStateHashes = new();
        private int _requestedLocomotionState;
        private bool _hasRequestedLocomotionState;
        private EBossAttackType _trackedAttackType;
        private int _trackedAttackState;
        private float _lastAttackElapsed;
        private float _attackDuration;
        private int _trackingVersion;
        private int _pendingAttackFrames;
        private bool _isTrackingAttack;
        private Transform _attack5MotionRoot;
        private Vector3 _attack5MotionBasePosition;
        private Vector3 _lastAttack5MotionPosition;
        private bool _missingAttack5MotionRootLogged;
        private bool _suppressAttack5MotionRoot;
        private int _lastAttack5StateHash;

        public event Action<EBossAttackType, float, float>
            OnAttackAnimationElapsed;
        public event Action<EBossAttackType>
            OnAttackAnimationCompleted;
        public event Action<Vector3, float> OnAttackRootMotion;

        internal bool IsTrackingAttack => _isTrackingAttack;
        internal bool CanTrackAttack =>
            isActiveAndEnabled &&
            _animator != null &&
            _animator.isActiveAndEnabled &&
            _animator.runtimeAnimatorController != null;

        private void Awake()
        {
            ResolveAnimator();
        }

        private void OnDisable()
        {
            CancelAttackTracking();
            _hasRequestedLocomotionState = false;
        }

        private void OnValidate()
        {
            _crossFadeDuration = Mathf.Max(0f, _crossFadeDuration);
        }

        public bool Bind(Animator p_animator)
        {
            Animator nextAnimator = p_animator != null
                ? p_animator
                : GetComponentInChildren<Animator>(true);

            if (_animator != nextAnimator)
            {
                CancelAttackTracking();
                _hasRequestedLocomotionState = false;
                _attack5MotionRoot = null;
            }

            _animator = nextAnimator;
            return _animator != null &&
                   _animator.runtimeAnimatorController != null;
        }

        public bool PlayIdle()
        {
            return PlayLocomotion(IdleState, "Idle");
        }

        public bool PlayChase()
        {
            return PlayLocomotion(ChaseState, "Chase");
        }

        public bool PlayAttack(EBossAttackType p_attackType)
        {
            return PlayAttackState(p_attackType,
                GetAttackStateHash(p_attackType), p_attackType.ToString());
        }

        // AttackData에서 지정한 Animator State를 재생한다.
        public bool PlayAttack(EBossAttackType p_attackType,
            string p_animatorStatePath)
        {
            if (string.IsNullOrWhiteSpace(p_animatorStatePath))
                return false;

            return PlayAttackState(p_attackType,
                Animator.StringToHash(p_animatorStatePath),
                p_animatorStatePath);
        }

        private bool PlayAttackState(EBossAttackType p_attackType,
            int p_stateHash, string p_stateName)
        {
            int stateHash = p_stateHash;
            if (stateHash == 0 ||
                !HasState(stateHash, p_stateName))
            {
                return false;
            }

            if (p_attackType == EBossAttackType.Attack5 &&
                !ResolveAttack5MotionRoot())
            {
                return false;
            }

            CancelAttackTracking();
            _hasRequestedLocomotionState = false;
            _animator.CrossFadeInFixedTime(
                stateHash,
                _crossFadeDuration,
                BaseLayer,
                0f);

            _trackedAttackType = p_attackType;
            _trackedAttackState = stateHash;
            _isTrackingAttack = true;
            if (p_attackType == EBossAttackType.Attack5)
            {
                _lastAttack5StateHash = stateHash;
                _attack5MotionBasePosition = _attack5MotionRoot.localPosition;
                _lastAttack5MotionPosition = _attack5MotionBasePosition;
                _suppressAttack5MotionRoot = true;
            }
            return true;
        }

        public void CancelAttackTracking()
        {
            if (_isTrackingAttack &&
                _trackedAttackType == EBossAttackType.Attack5 &&
                _attack5MotionRoot != null)
            {
                _attack5MotionRoot.localPosition =
                    _attack5MotionBasePosition;
            }

            _trackingVersion++;
            _isTrackingAttack = false;
            _trackedAttackState = 0;
            _lastAttackElapsed = 0f;
            _attackDuration = 0f;
            _pendingAttackFrames = 0;
        }

        private void LateUpdate()
        {
            if (!_isTrackingAttack ||
                _trackedAttackType != EBossAttackType.Attack5)
            {
                SuppressAttack5RootAfterTracking();
            }

            if (!_isTrackingAttack)
                return;

            if (!ResolveAnimator() ||
                !_animator.isActiveAndEnabled ||
                !_animator.isInitialized ||
                _animator.layerCount <= BaseLayer)
            {
                CancelAttackTracking();
                return;
            }

            bool isTransitioning = _animator.IsInTransition(BaseLayer);
            AnimatorStateInfo current =
                _animator.GetCurrentAnimatorStateInfo(BaseLayer);
            AnimatorStateInfo next = isTransitioning
                ? _animator.GetNextAnimatorStateInfo(BaseLayer)
                : default;

            // 같은 공격을 재시작할 때는 이전 재생 상태가 아닌 전환 대상의 시간을 읽는다.
            bool nextIsAttack = isTransitioning &&
                                next.fullPathHash == _trackedAttackState;
            bool currentIsAttack =
                current.fullPathHash == _trackedAttackState;

            if (isTransitioning && currentIsAttack && !nextIsAttack)
            {
                CancelAttackTracking();
                return;
            }

            if (!nextIsAttack && !currentIsAttack)
            {
                if (++_pendingAttackFrames > 1)
                    CancelAttackTracking();
                return;
            }

            _pendingAttackFrames = 0;
            CaptureAttack5RootMotion();
            AnimatorStateInfo attackState = nextIsAttack
                ? next
                : current;
            _attackDuration = Mathf.Max(0f, attackState.length);
            _lastAttackElapsed = Mathf.Max(
                _lastAttackElapsed,
                Mathf.Clamp01(attackState.normalizedTime) *
                _attackDuration);

            int version = _trackingVersion;
            EBossAttackType attackType = _trackedAttackType;
            OnAttackAnimationElapsed?.Invoke(
                attackType,
                _lastAttackElapsed,
                _attackDuration);

            if (!_isTrackingAttack || version != _trackingVersion)
                return;

            if (currentIsAttack &&
                !isTransitioning &&
                current.normalizedTime >= 1f)
            {
                CancelAttackTracking();
                OnAttackAnimationCompleted?.Invoke(attackType);
            }
        }

        private bool PlayLocomotion(int p_stateHash, string p_stateName)
        {
            if (!HasState(p_stateHash, p_stateName))
                return false;

            bool alreadyRequested =
                _hasRequestedLocomotionState &&
                _requestedLocomotionState == p_stateHash;
            bool currentOrNextMatches =
                _animator.isInitialized &&
                (_animator.GetCurrentAnimatorStateInfo(BaseLayer)
                     .fullPathHash == p_stateHash ||
                 (_animator.IsInTransition(BaseLayer) &&
                  _animator.GetNextAnimatorStateInfo(BaseLayer)
                      .fullPathHash == p_stateHash));

            CancelAttackTracking();
            if (alreadyRequested && currentOrNextMatches)
                return true;

            _animator.CrossFadeInFixedTime(
                p_stateHash,
                _crossFadeDuration,
                BaseLayer,
                0f);
            _requestedLocomotionState = p_stateHash;
            _hasRequestedLocomotionState = true;
            return true;
        }

        private bool HasState(int p_stateHash, string p_stateName)
        {
            if (!ResolveAnimator() ||
                !_animator.isActiveAndEnabled ||
                _animator.runtimeAnimatorController == null ||
                _animator.layerCount <= BaseLayer)
            {
                return false;
            }

            if (_animator.HasState(BaseLayer, p_stateHash))
                return true;

            if (_missingStateHashes.Add(p_stateHash))
            {
                Debug.LogWarning(
                    $"Boss Animator 상태를 찾을 수 없습니다: {p_stateName}",
                    this);
            }

            return false;
        }

        private bool ResolveAnimator()
        {
            if (_animator == null)
                _animator = GetComponentInChildren<Animator>(true);

            return _animator != null;
        }

        private bool ResolveAttack5MotionRoot()
        {
            _attack5MotionRoot ??= _animator.transform.Find("root");
            if (_attack5MotionRoot != null)
                return true;

            if (!_missingAttack5MotionRootLogged)
            {
                Debug.LogWarning(
                    "Attack5 애니메이션의 root 본을 찾을 수 없습니다.",
                    this);
                _missingAttack5MotionRootLogged = true;
            }

            return false;
        }

        // 모델 본의 전진을 읽고 제자리로 돌려 보스 Rigidbody에만 이동을 전달한다.
        private void CaptureAttack5RootMotion()
        {
            if (_trackedAttackType != EBossAttackType.Attack5 ||
                _attack5MotionRoot == null)
            {
                return;
            }

            Vector3 currentPosition = _attack5MotionRoot.localPosition;
            Vector3 localDelta =
                currentPosition - _lastAttack5MotionPosition;
            _lastAttack5MotionPosition = currentPosition;
            _attack5MotionRoot.localPosition =
                _attack5MotionBasePosition;

            if (localDelta.sqrMagnitude < 0.00000001f)
                return;

            Transform parent = _attack5MotionRoot.parent;
            Vector3 worldDelta = parent != null
                ? parent.TransformVector(localDelta)
                : localDelta;
            OnAttackRootMotion?.Invoke(worldDelta, Time.deltaTime);
        }

        // Attack5에서 Chase로 블렌딩되는 동안 본의 잔여 전진을 지운다.
        private void SuppressAttack5RootAfterTracking()
        {
            if (!_suppressAttack5MotionRoot ||
                _attack5MotionRoot == null)
            {
                return;
            }

            _attack5MotionRoot.localPosition =
                _attack5MotionBasePosition;

            if (!ResolveAnimator() || !_animator.isInitialized ||
                _animator.layerCount <= BaseLayer)
            {
                return;
            }

            AnimatorStateInfo current =
                _animator.GetCurrentAnimatorStateInfo(BaseLayer);
            bool currentIsAttack5 =
                current.fullPathHash == _lastAttack5StateHash;
            bool nextIsAttack5 = _animator.IsInTransition(BaseLayer) &&
                                 _animator.GetNextAnimatorStateInfo(BaseLayer)
                                     .fullPathHash == _lastAttack5StateHash;

            if (!currentIsAttack5 && !nextIsAttack5)
                _suppressAttack5MotionRoot = false;
        }

        private static int GetAttackStateHash(
            EBossAttackType p_attackType)
        {
            return p_attackType switch
            {
                EBossAttackType.Attack1 => Attack1State,
                EBossAttackType.Attack2 => Attack2State,
                EBossAttackType.Attack3 => Attack3State,
                EBossAttackType.Attack4 => Attack4State,
                EBossAttackType.Attack5 => Attack5State,
                EBossAttackType.Attack6 => Attack6State,
                EBossAttackType.Provokes => ProvokesState,
                _ => 0
            };
        }
    }
}

using UnityEngine;

namespace Alpha.Boss
{
    internal interface IBossAttackState
    {
        bool HasStarted { get; }
        void Enter();
        void Tick(float p_deltaTime);
        void Exit();
    }

    // 방향을 맞춘 뒤 Attack1 클립과 지정 시점의 이펙트를 실행한다.
    internal sealed class BossAttack1State : IBossAttackState
    {
        private readonly BossCombatFlow _flow;
        private BossAttackData.AttackEntry _data;
        private bool _hasStarted;
        private bool _completed;

        public bool HasStarted => _hasStarted;

        public BossAttack1State(BossCombatFlow p_flow)
        {
            _flow = p_flow;
        }

        public void Enter()
        {
            BossCore core = _flow.Core;
            _hasStarted = false;
            _completed = false;
            _flow.TryGetAttackData(EBossAttackType.Attack1, out _data);
            core.Locomotion.Stop();
            core.Animation.PlayIdle();
            core.Animation.OnAttackAnimationElapsed += HandleElapsed;
            core.Animation.OnAttackAnimationCompleted += HandleCompleted;
        }

        public void Tick(float p_deltaTime)
        {
            BossCore core = _flow.Core;
            core.Locomotion.Stop();

            if (_data == null)
            {
                _flow.FinishAttack(EBossAttackType.Attack1);
                return;
            }

            if (_hasStarted)
                return;

            Transform target = core.Target;
            if (target == null ||
                !_flow.IsTargetInAttackRange(EBossAttackType.Attack1))
            {
                _flow.CancelAttack();
                return;
            }

            if (!core.Locomotion.RotateTowards(
                    target.position, p_deltaTime))
            {
                return;
            }

            // 비대칭 차단체가 회전한 뒤의 거리로 공격 시작을 확정한다.
            if (!_flow.IsTargetInAttackRange(EBossAttackType.Attack1))
            {
                _flow.CancelAttack();
                return;
            }

            if (!core.Animation.PlayAttack(EBossAttackType.Attack1,
                    _data.AnimatorStatePath))
            {
                _flow.FinishAttack(EBossAttackType.Attack1);
                return;
            }

            _hasStarted = true;
            core.Effect.BeginAttack(_data);
            core.Effect.AdvanceAttack(0f);
        }

        public void Exit()
        {
            BossCore core = _flow.Core;
            core.Animation.OnAttackAnimationElapsed -= HandleElapsed;
            core.Animation.OnAttackAnimationCompleted -= HandleCompleted;
            core.Animation.CancelAttackTracking();
            core.Effect.EndAttack(_completed);
            core.Locomotion.Stop();
            _data = null;
        }

        private void HandleElapsed(
            EBossAttackType p_type,
            float p_elapsed,
            float p_duration)
        {
            if (!_hasStarted || p_type != EBossAttackType.Attack1)
                return;

            _flow.Core.Effect.AdvanceAttack(p_elapsed);
        }

        private void HandleCompleted(EBossAttackType p_type)
        {
            if (!_hasStarted || p_type != EBossAttackType.Attack1)
                return;

            _completed = true;
            _flow.FinishAttack(EBossAttackType.Attack1);
        }
    }

    // 대상의 지면 위치를 기록하고 Attack2 이펙트를 그 위치에서 재생한다.
    internal sealed class BossAttack2State : IBossAttackState
    {
        private readonly BossCombatFlow _flow;
        private BossAttackData.AttackEntry _data;
        private bool _hasStarted;
        private bool _completed;
        private Vector3 _targetPosition;
        private Quaternion _targetRotation;

        public bool HasStarted => _hasStarted;

        internal bool HasTargetSnapshot => _hasStarted;
        internal Vector3 TargetPosition => _targetPosition;
        internal Quaternion TargetRotation => _targetRotation;

        public BossAttack2State(BossCombatFlow p_flow)
        {
            _flow = p_flow;
        }

        public void Enter()
        {
            BossCore core = _flow.Core;
            _hasStarted = false;
            _completed = false;
            _flow.TryGetAttackData(EBossAttackType.Attack2, out _data);
            core.Locomotion.Stop();
            core.Animation.PlayIdle();
            core.Animation.OnAttackAnimationElapsed += HandleElapsed;
            core.Animation.OnAttackAnimationCompleted += HandleCompleted;
        }

        public void Tick(float p_deltaTime)
        {
            BossCore core = _flow.Core;
            core.Locomotion.Stop();

            if (_data == null)
            {
                _flow.FinishAttack(EBossAttackType.Attack2);
                return;
            }

            if (_hasStarted || core.Target == null ||
                !core.Locomotion.RotateTowards(
                    core.Target.position, p_deltaTime))
            {
                return;
            }

            if (!core.Animation.PlayAttack(EBossAttackType.Attack2,
                    _data.AnimatorStatePath))
            {
                _flow.FinishAttack(EBossAttackType.Attack2);
                return;
            }

            Vector3 targetPosition = core.Target.position;
            // Attack2는 공격 시작 순간의 지면 위치를 기록한다.
            _targetPosition = _data.GroundProbe != null &&
                _data.GroundProbe.TryFindGround(targetPosition, null,
                    out Vector3 groundPosition, 0.5f)
                ? groundPosition
                : targetPosition;
            _targetRotation = core.Target.rotation;
            _hasStarted = true;
            core.Effect.BeginAttackAtWorld(
                _data, _targetPosition);
            core.Effect.AdvanceAttack(0f);
        }

        public void Exit()
        {
            BossCore core = _flow.Core;
            core.Animation.OnAttackAnimationElapsed -= HandleElapsed;
            core.Animation.OnAttackAnimationCompleted -= HandleCompleted;
            core.Animation.CancelAttackTracking();
            core.Effect.EndAttack(_completed);
            core.Locomotion.Stop();
            _data = null;
        }

        private void HandleElapsed(
            EBossAttackType p_type,
            float p_elapsed,
            float p_duration)
        {
            if (!_hasStarted || p_type != EBossAttackType.Attack2)
                return;

            _flow.Core.Effect.AdvanceAttack(p_elapsed);
        }

        private void HandleCompleted(EBossAttackType p_type)
        {
            if (!_hasStarted || p_type != EBossAttackType.Attack2)
                return;

            _completed = true;
            _flow.FinishAttack(EBossAttackType.Attack2);
        }
    }

    // Attack5 클립의 전진량을 이동 Module에 전달한다.
    internal sealed class BossAttack5State : IBossAttackState
    {
        private readonly BossCombatFlow _flow;
        private BossAttackData.AttackEntry _data;
        private bool _hasStarted;
        private bool _completed;

        public bool HasStarted => _hasStarted;

        public BossAttack5State(BossCombatFlow p_flow)
        {
            _flow = p_flow;
        }

        public void Enter()
        {
            BossCore core = _flow.Core;
            _hasStarted = false;
            _completed = false;
            _flow.TryGetAttackData(EBossAttackType.Attack5, out _data);
            core.Locomotion.Stop();
            core.Animation.PlayIdle();
            core.Animation.OnAttackRootMotion += HandleRootMotion;
            core.Animation.OnAttackAnimationElapsed += HandleElapsed;
            core.Animation.OnAttackAnimationCompleted += HandleCompleted;
        }

        public void Tick(float p_deltaTime)
        {
            BossCore core = _flow.Core;
            core.Locomotion.Stop();

            if (_data == null)
            {
                _flow.FinishAttack(EBossAttackType.Attack5);
                return;
            }

            if (_hasStarted)
                return;

            // 회전 중 대상이 돌진 거리에서 벗어났다면 쿨다운 없이 추격으로 돌아간다.
            Transform target = core.Target;
            if (target == null ||
                !_flow.IsTargetInAttackRange(EBossAttackType.Attack5))
            {
                _flow.CancelAttack();
                return;
            }

            if (!core.Locomotion.RotateTowards(
                    target.position, p_deltaTime))
            {
                return;
            }

            if (!_flow.IsTargetInAttackRange(EBossAttackType.Attack5))
            {
                _flow.CancelAttack();
                return;
            }

            if (!core.Animation.PlayAttack(EBossAttackType.Attack5,
                    _data.AnimatorStatePath))
            {
                _flow.FinishAttack(EBossAttackType.Attack5);
                return;
            }

            _hasStarted = true;
            core.Effect.BeginAttack(_data);
            core.Effect.AdvanceAttack(0f);
        }

        public void Exit()
        {
            BossCore core = _flow.Core;
            core.Animation.OnAttackRootMotion -= HandleRootMotion;
            core.Animation.OnAttackAnimationElapsed -= HandleElapsed;
            core.Animation.OnAttackAnimationCompleted -= HandleCompleted;
            core.Animation.CancelAttackTracking();
            core.Effect.EndAttack(_completed);
            if (!_completed)
                core.Locomotion.ClearPendingRootMotion();
            core.Locomotion.Stop();
            _data = null;
        }

        private void HandleRootMotion(
            Vector3 p_worldDelta,
            float p_sampleDuration)
        {
            if (_hasStarted)
            {
                _flow.Core.Locomotion.QueueRootMotion(
                    p_worldDelta, p_sampleDuration);
            }
        }

        private void HandleElapsed(
            EBossAttackType p_type,
            float p_elapsed,
            float p_duration)
        {
            if (!_hasStarted || p_type != EBossAttackType.Attack5)
                return;

            _flow.Core.Effect.AdvanceAttack(p_elapsed);
        }

        private void HandleCompleted(EBossAttackType p_type)
        {
            if (!_hasStarted || p_type != EBossAttackType.Attack5)
                return;

            _completed = true;
            _flow.FinishAttack(EBossAttackType.Attack5);
        }
    }
}

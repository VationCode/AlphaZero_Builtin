using System;
using System.Collections.Generic;
using Alpha.Utility;
using UnityEngine;

namespace Alpha.Boss
{
    public enum EBossAttackDistanceType
    {
        Near = 0,
        Far = 1,
        Global = 2
    }

    public enum EBossAttackTargetType
    {
        Single = 0,
        Area = 1
    }

    public enum EBossHitReactionType
    {
        Normal = 0,
        Heavy = 1,
        Knockdown = 2
    }

    // Attack 자식 객체가 공격별 설정을 보관한다. 실행 시점과 판정은 Combat 상태가 결정한다.
    [DisallowMultipleComponent]
    public sealed class BossAttackData : MonoBehaviour
    {
        [Serializable]
        public struct EffectData
        {
            [SerializeField] private GameObject _effectPrefab;
            [SerializeField] private Transform _anchor;
            [SerializeField] private Transform _parent;
            [Tooltip("원본 클립 기준 시작 시각(초). 공격의 Timing Scale을 곱해 실제 시작 시각을 구합니다.")]
            [SerializeField, Min(0f)] private float _startTimeSeconds;
            [Tooltip("이펙트 생성 후 유지할 시간(초).")]
            [SerializeField, Min(0f)] private float _durationSeconds;

            public GameObject EffectPrefab => _effectPrefab;
            public Transform Anchor => _anchor;
            public Transform Parent => _parent;
            public float StartTimeSeconds => _startTimeSeconds;
            public float DurationSeconds => _durationSeconds;
        }

        [Serializable]
        public sealed class AttackEntry
        {
            [Header("Basic Info")]
            [SerializeField] private string _id;
            [SerializeField] private string _name;

            [Header("Targeting")]
            [SerializeField] private EBossAttackDistanceType _distanceType;
            [SerializeField] private EBossAttackTargetType _targetType;
            [Tooltip("보스 본체 박스 표면에서 플레이어 중심까지의 수평 거리입니다.")]
            [SerializeField, Min(0f)] private float _minDistance;
            [Tooltip("보스 본체 박스 표면에서 플레이어 중심까지의 수평 거리입니다.")]
            [SerializeField, Min(0f)] private float _maxDistance;

            [Header("Target Ground")]
            [SerializeField] private GroundProbe _groundProbe = new();

            [Header("Damage & Reaction")]
            [SerializeField, Min(0f)] private float _damage;
            [SerializeField] private EBossHitReactionType _hitReaction;

            [Header("Hit Timing")]
            [SerializeField, Min(0f)] private float _hitStartSeconds;
            [SerializeField, Min(0f)] private float _hitDurationSeconds;

            [Header("Attack Area")]
            [SerializeField] private BossAttackAreaSettings _area = new();

            [Header("Animation")]
            [Tooltip("Animator의 전체 State 경로. 예: Base Layer.Attack1")]
            [SerializeField] private string _animatorStatePath;
            [Tooltip("원본 클립의 시작 시각을 실제 재생 시각으로 조율하는 배율.")]
            [SerializeField, Min(0.01f)] private float _timingScale = 1f;

            [Header("Effects")]
            [SerializeField] private List<EffectData> _effects = new();

            public string Id => _id;
            public string Name => _name;
            public EBossAttackDistanceType DistanceType => _distanceType;
            public EBossAttackTargetType TargetType => _targetType;
            public float MinDistance => _minDistance;
            public float MaxDistance => _maxDistance;
            public GroundProbe GroundProbe => _groundProbe;
            public float Damage => _damage;
            public EBossHitReactionType HitReaction => _hitReaction;
            public float HitStartSeconds => _hitStartSeconds;
            public float HitDurationSeconds => _hitDurationSeconds;
            public BossAttackAreaSettings Area => _area;
            public string AnimatorStatePath => _animatorStatePath;
            public float TimingScale => _timingScale > 0f
                ? Mathf.Max(0.01f, _timingScale)
                : 1f;
            public IReadOnlyList<EffectData> Effects => _effects;

            internal void Validate()
            {
                _minDistance = Mathf.Max(0f, _minDistance);
                //_maxDistance = Mathf.Max(_minDistance, _maxDistance);
                _groundProbe?.Validate();
                _damage = Mathf.Max(0f, _damage);
                _hitStartSeconds = Mathf.Max(0f, _hitStartSeconds);
                _hitDurationSeconds = Mathf.Max(0f, _hitDurationSeconds);
                _timingScale = TimingScale;
                _area?.Validate();
            }
        }

        [Header("Attacks")]
        [SerializeField] private List<AttackEntry> _attacks = new();

        public IReadOnlyList<AttackEntry> Attacks => _attacks;

        // ID를 고정 키로 사용해 상태 클래스가 해당 공격 설정을 찾는다.
        public bool TryGet(string p_id, out AttackEntry p_entry)
        {
            if (!string.IsNullOrEmpty(p_id) && _attacks != null)
            {
                for (int index = 0; index < _attacks.Count; index++)
                {
                    AttackEntry entry = _attacks[index];
                    if (entry != null &&
                        string.Equals(entry.Id, p_id,
                            StringComparison.Ordinal))
                    {
                        p_entry = entry;
                        return true;
                    }
                }
            }

            p_entry = null;
            return false;
        }

        private void OnValidate()
        {
            if (_attacks == null)
                return;

            for (int index = 0; index < _attacks.Count; index++)
                _attacks[index]?.Validate();
        }
    }
}

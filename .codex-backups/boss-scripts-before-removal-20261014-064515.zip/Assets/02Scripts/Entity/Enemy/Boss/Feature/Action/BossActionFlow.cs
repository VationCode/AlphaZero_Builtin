using UnityEngine;

namespace Alpha.Boss
{
    // 시네마틱과 생존 상태를 확인하고 상위 행동 상태를 갱신한다.
    [DisallowMultipleComponent]
    public sealed class BossActionFlow : MonoBehaviour
    {
        private BossCore _core;
        private BossActionStateMachine _actions;
        private bool _isDead;

        internal BossCore Core => _core;
        internal bool CanAct =>
            !_isDead &&
            _core != null &&
            _core.Target != null &&
            _core.Player?.HealthModule != null &&
            _core.Player.HealthModule.CurrentHealth > 0f &&
            _core.HealthModule != null &&
            !_core.HealthModule.IsDead &&
            _core.Cinematic?.Context?.CurrentState ==
                EBossCinematicState.Completed;

        // Core가 외부 참조를 받은 뒤 상태 객체를 한 번 구성한다.
        public bool Bind(BossCore p_core)
        {
            if (p_core == null)
                return false;

            _actions?.Dispose();
            _core = p_core;
            _isDead = false;
            _actions = new BossActionStateMachine(this);
            return true;
        }

        public void HandleDeath()
        {
            if (_isDead)
                return;

            _isDead = true;
            _actions?.Dispose();
            _core?.CombatFlow?.CancelAttack();
            _core?.Locomotion?.Stop();
            _core?.Animation?.CancelAttackTracking();
        }

        private void FixedUpdate()
        {
            if (!_isDead)
                _actions?.Tick(Time.fixedDeltaTime);
        }

        private void OnDisable()
        {
            if (_isDead || _core == null)
                return;

            _actions?.ResetToIdle();
            _core?.Locomotion?.Stop();
        }

        private void OnDestroy()
        {
            _actions?.Dispose();
        }

    }
}

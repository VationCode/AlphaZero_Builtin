using System;
using UnityEngine;

namespace Alpha.Boss
{
    // 공격 선택과 실행 상태를 관리하고, 공격별 설정은 Attack 자식에서 읽는다.
    [DisallowMultipleComponent]
    public sealed class BossCombatFlow : MonoBehaviour
    {
        [Header("Targeting Origin")]
        [Tooltip("플레이어와 충돌하는 보스 본체 박스입니다.")]
        [SerializeField] private BoxCollider _bodyCollider;

        [Header("Attack Timing")]
        [SerializeField, Min(0f)] private float _attackCooldown = 1.25f;

        [Header("Attack Data")]
        [SerializeField] private BossAttackData _attackData;

        private BossCore _core;
        private BossAttack1State _attack1;
        private BossAttack2State _attack2;
        private BossAttack5State _attack5;
        private IBossAttackState _current;
        private float _nextAttackTime;

        internal BossCore Core => _core;
        internal BoxCollider BodyCollider => _bodyCollider;
        internal bool IsAttacking => _current != null;
        internal bool CanStartAttack =>
            isActiveAndEnabled && _core != null && _current == null &&
            _core.Animation != null && _core.Animation.CanTrackAttack &&
            Time.time >= _nextAttackTime;

        // 거리만으로 공격 후보를 정한다. 실행 가능 시점은 CanStartAttack이 판단한다.
        internal bool TrySelectAttack(float p_horizontalDistance,
            out EBossAttackType p_type)
        {
            p_type = default;
            if (IsInAttackRange(EBossAttackType.Attack1,
                    p_horizontalDistance))
            {
                p_type = EBossAttackType.Attack1;
                return true;
            }

            if (IsInAttackRange(EBossAttackType.Attack5,
                    p_horizontalDistance))
            {
                p_type = EBossAttackType.Attack5;
                return true;
            }

            return false;
        }

        internal bool IsTargetInAttackRange(EBossAttackType p_type)
        {
            if (_core == null || _core.Target == null)
                return false;

            return IsInAttackRange(p_type,
                GetTargetingDistance(_core.Target.position));
        }

        // 보스 본체 박스의 바깥면에서 대상 중심까지 수평 거리를 잰다.
        internal float GetTargetingDistance(Vector3 p_targetPosition)
        {
            if (_bodyCollider == null || !_bodyCollider.enabled)
            {
                Vector3 offset = Vector3.ProjectOnPlane(
                    p_targetPosition - transform.position, Vector3.up);
                return offset.magnitude;
            }

            Vector3 horizontalPosition = p_targetPosition;
            horizontalPosition.y = _bodyCollider.bounds.center.y;
            Vector3 closestPoint = _bodyCollider.ClosestPoint(horizontalPosition);
            return Vector3.ProjectOnPlane(
                horizontalPosition - closestPoint, Vector3.up).magnitude;
        }

        private bool IsInAttackRange(EBossAttackType p_type,
            float p_horizontalDistance)
        {
            if (p_horizontalDistance < 0f ||
                !TryGetTargetingRange(p_type,
                    out float minDistance, out float maxDistance))
            {
                return false;
            }

            return p_horizontalDistance >= minDistance &&
                   p_horizontalDistance <= maxDistance;
        }

        // 공격 선택과 Scene 미리보기가 동일한 유효 거리 구간을 사용한다.
        internal bool TryGetTargetingRange(EBossAttackType p_type,
            out float p_minDistance, out float p_maxDistance)
        {
            p_minDistance = 0f;
            p_maxDistance = 0f;
            if (!TryGetAttackData(p_type,
                    out BossAttackData.AttackEntry data))
            {
                return false;
            }

            p_minDistance = data.MinDistance;
            p_maxDistance = data.MaxDistance;
            return p_maxDistance >= p_minDistance;
        }

        internal bool TryGetAttackData(EBossAttackType p_type,
            out BossAttackData.AttackEntry p_data)
        {
            p_data = null;
            return _attackData != null &&
                   _attackData.TryGet(p_type.ToString(), out p_data);
        }

        internal event Action OnAttackFinished;

        // Core가 View와 이동 기능을 연결한 뒤 공격 상태를 준비한다.
        public bool Bind(BossCore p_core)
        {
            _attackData ??= GetComponentInChildren<BossAttackData>(true);
            _bodyCollider ??= p_core != null
                ? p_core.GetComponent<BoxCollider>()
                : null;
            if (p_core == null || _attackData == null)
                return false;

            CancelAttack();
            _core = p_core;
            _attack1 = new BossAttack1State(this);
            _attack2 = new BossAttack2State(this);
            _attack5 = new BossAttack5State(this);
            _nextAttackTime = 0f;
            return true;
        }

        // Chase가 선택한 공격을 현재 거리에서 다시 확인한 뒤 시작한다.
        internal bool TryStartAttack(EBossAttackType p_type)
        {
            if (!CanStartAttack || !IsTargetInAttackRange(p_type))
                return false;

            IBossAttackState next = p_type switch
            {
                EBossAttackType.Attack1 => _attack1,
                EBossAttackType.Attack5 => _attack5,
                _ => null
            };
            if (next == null)
                return false;

            _current = next;
            _current.Enter();
            return true;
        }

        // Action의 단일 FixedUpdate에서 호출해 이동량 적용 순서를 고정한다.
        internal void Tick(float p_deltaTime)
        {
            _current?.Tick(p_deltaTime);

            // View/Animator가 중단되어 완료 이벤트가 끊기면 공격을 종료한다.
            if (_current is { HasStarted: true } &&
                (!_core.Animation.CanTrackAttack ||
                 !_core.Animation.IsTrackingAttack))
            {
                CancelAttack();
            }
        }

        internal void FinishAttack(EBossAttackType p_completedType)
        {
            if (_current == null)
                return;

            IBossAttackState completed = _current;
            _current = null;
            _nextAttackTime = Time.time + _attackCooldown;
            completed.Exit();
            OnAttackFinished?.Invoke();
        }

        internal void CancelAttack()
        {
            IBossAttackState cancelled = _current;
            _current = null;
            cancelled?.Exit();
        }

        internal bool TryGetAttack2TargetPose(
            out Vector3 p_position,
            out Quaternion p_rotation)
        {
            if (_attack2 != null && _current == _attack2 &&
                _attack2.HasTargetSnapshot)
            {
                p_position = _attack2.TargetPosition;
                p_rotation = _attack2.TargetRotation;
                return true;
            }

            p_position = default;
            p_rotation = default;
            return false;
        }

        private void OnDisable()
        {
            if (_core != null)
                CancelAttack();
        }

        private void OnDestroy()
        {
            if (_core != null)
                CancelAttack();
        }

        private void OnValidate()
        {
            _attackData ??= GetComponentInChildren<BossAttackData>(true);
            _bodyCollider ??= GetComponentInParent<BossCore>()?.GetComponent<BoxCollider>();
            _attackCooldown = Mathf.Max(0f, _attackCooldown);
        }
    }
}

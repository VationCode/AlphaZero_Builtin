using Alpha.Combat;
using Alpha.Living;
using Alpha.Player;
using UnityEngine;

namespace Alpha.Boss
{
    // 보스의 기능을 조립하고 Installer로부터 외부 참조를 받는다.
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Rigidbody))]
    public sealed class BossCore : MonoBehaviour
    {
        [Header("Scene References")]
        [SerializeField] private Rigidbody _body;
        [SerializeField] private Animator _animator;
        [SerializeField] private BossLocomotionModule _locomotion;
        [SerializeField] private BossAnimationView _animationView;
        [SerializeField] private BossAttackEffectView _effectView;
        [SerializeField] private BossActionFlow _actionFlow;
        [SerializeField] private BossCombatFlow _combatFlow;
        [SerializeField] private LivingModule _healthModule;
        [SerializeField] private DamageReceiverModule _damageReceiver;

        private PlayerCore _player;
        private BossCinematicRoot _cinematic;

        public HealthContext HealthContext { get; } = new();

        internal Transform Target => _player == null
            ? null
            : (_player.PlayerTr != null
                ? _player.PlayerTr
                : _player.transform);
        internal BossLocomotionModule Locomotion => _locomotion;
        internal BossAnimationView Animation => _animationView;
        internal BossAttackEffectView Effect => _effectView;
        internal BossActionFlow ActionFlow => _actionFlow;
        internal BossCombatFlow CombatFlow => _combatFlow;
        internal LivingModule HealthModule => _healthModule;
        internal PlayerCore Player => _player;
        internal BossCinematicRoot Cinematic => _cinematic;

        internal bool TryGetAttack2TargetPose(
            out Vector3 p_position,
            out Quaternion p_rotation)
        {
            if (_combatFlow != null)
                return _combatFlow.TryGetAttack2TargetPose(
                    out p_position, out p_rotation);

            p_position = default;
            p_rotation = default;
            return false;
        }

        private void Awake()
        {
            ResolveOwnedReferences();
        }

        // 외부 참조를 받은 뒤 자식 기능과 공용 피해 수신을 연결한다.
        public bool Bind(PlayerCore p_player, BossCinematicRoot p_cinematic)
        {
            ResolveOwnedReferences();

            if (p_player == null || p_cinematic == null ||
                _body == null || _animator == null ||
                _locomotion == null || _animationView == null ||
                _effectView == null || _actionFlow == null ||
                _combatFlow == null ||
                _healthModule == null || _damageReceiver == null ||
                !_locomotion.Bind(_body) ||
                !_animationView.Bind(_animator))
            {
                Debug.LogError("Boss 기능 참조를 연결하지 못했습니다.", this);
                return false;
            }

            _player = p_player;
            _cinematic = p_cinematic;
            _healthModule.OnDeath -= HandleDeath;
            _healthModule.Bind(HealthContext);
            _damageReceiver.Bind(transform, _healthModule.TryDecreaseHealth);
            _healthModule.OnDeath += HandleDeath;

            if (_combatFlow.Bind(this) && _actionFlow.Bind(this))
                return true;

            _healthModule.OnDeath -= HandleDeath;
            _damageReceiver.Unbind();
            return false;
        }

        private void OnDestroy()
        {
            if (_healthModule != null)
                _healthModule.OnDeath -= HandleDeath;

            _damageReceiver?.Unbind();
        }

        private void ResolveOwnedReferences()
        {
            _body ??= GetComponent<Rigidbody>();
            _animator ??= GetComponentInChildren<Animator>(true);
            _locomotion ??= GetComponentInChildren<BossLocomotionModule>(true);
            _animationView ??= GetComponentInChildren<BossAnimationView>(true);
            _effectView ??= GetComponentInChildren<BossAttackEffectView>(true);
            _actionFlow ??= GetComponentInChildren<BossActionFlow>(true);
            _combatFlow ??= GetComponentInChildren<BossCombatFlow>(true);
            _healthModule ??= GetComponentInChildren<LivingModule>(true);
            _damageReceiver ??= GetComponent<DamageReceiverModule>();
        }

        private void HandleDeath()
        {
            _actionFlow?.HandleDeath();
        }

        private void OnValidate()
        {
            ResolveOwnedReferences();
        }
    }
}

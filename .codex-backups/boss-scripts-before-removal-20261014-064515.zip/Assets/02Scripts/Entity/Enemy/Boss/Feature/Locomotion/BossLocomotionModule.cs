using UnityEngine;

namespace Alpha.Boss
{
    // 상태의 명령에 따라 Rigidbody의 수평 이동과 Y축 회전을 수행한다.
    [DisallowMultipleComponent]
    public sealed class BossLocomotionModule : MonoBehaviour
    {
        [SerializeField] private Rigidbody _body;
        [SerializeField, Min(0f)] private float _moveSpeed = 5f;
        [SerializeField, Min(0f)] private float _turnSpeed = 180f;
        [SerializeField, Range(0f, 45f)] private float _facingTolerance = 5f;
        private Vector3 _pendingRootMotion;
        private float _pendingRootMotionDuration;

        public bool Bind(Rigidbody p_body)
        {
            _body = p_body != null
                ? p_body
                : GetComponentInParent<Rigidbody>();
            return _body != null;
        }

        // 대상의 수평 위치를 따라가며 진행 방향으로 회전한다.
        public void MoveTowards(Vector3 p_destination, float p_deltaTime)
        {
            if (_body == null)
                return;

            Vector3 offset = Vector3.ProjectOnPlane(
                p_destination - _body.position, Vector3.up);
            if (offset.sqrMagnitude < 0.0001f)
            {
                Stop();
                return;
            }

            Vector3 direction = offset.normalized;
            RotateDirection(direction, p_deltaTime);

            Vector3 velocity = _body.linearVelocity;
            velocity.x = direction.x * _moveSpeed;
            velocity.z = direction.z * _moveSpeed;
            _body.linearVelocity = velocity;
        }

        // 제자리에서 대상 방향을 바라보고 각도가 허용치에 들면 완료한다.
        public bool RotateTowards(Vector3 p_destination, float p_deltaTime)
        {
            if (_body == null)
                return false;

            Vector3 direction = Vector3.ProjectOnPlane(
                p_destination - _body.position, Vector3.up);
            if (direction.sqrMagnitude < 0.0001f)
                return true;

            direction.Normalize();
            RotateDirection(direction, p_deltaTime);
            return Vector3.Angle(_body.rotation * Vector3.forward, direction)
                   <= _facingTolerance;
        }

        public void Stop()
        {
            if (_body == null)
                return;

            Vector3 velocity = _body.linearVelocity;
            velocity.x = 0f;
            velocity.z = 0f;
            _body.linearVelocity = velocity;
        }

        // 애니메이션에서 읽은 이동량을 다음 물리 프레임의 속도로 반영한다.
        public void QueueRootMotion(
            Vector3 p_worldDelta,
            float p_sampleDuration)
        {
            Vector3 horizontalDelta = Vector3.ProjectOnPlane(
                p_worldDelta, Vector3.up);
            if (horizontalDelta.sqrMagnitude < 0.00000001f)
                return;

            _pendingRootMotion += horizontalDelta;
            _pendingRootMotionDuration +=
                Mathf.Max(0.0001f, p_sampleDuration);
        }

        public void ApplyPendingRootMotion(float p_deltaTime)
        {
            if (_body == null || _pendingRootMotionDuration <= 0f ||
                p_deltaTime <= 0f)
            {
                return;
            }

            float consumedDuration = Mathf.Min(
                p_deltaTime, _pendingRootMotionDuration);
            Vector3 consumedDelta = _pendingRootMotion *
                                    (consumedDuration /
                                     _pendingRootMotionDuration);
            Vector3 velocity = _body.linearVelocity;
            velocity.x = consumedDelta.x / p_deltaTime;
            velocity.z = consumedDelta.z / p_deltaTime;
            _body.linearVelocity = velocity;

            _pendingRootMotion -= consumedDelta;
            _pendingRootMotionDuration -= consumedDuration;
            if (_pendingRootMotionDuration <= 0.0001f)
                ClearPendingRootMotion();
        }

        public void ClearPendingRootMotion()
        {
            _pendingRootMotion = Vector3.zero;
            _pendingRootMotionDuration = 0f;
        }

        private void RotateDirection(Vector3 p_direction, float p_deltaTime)
        {
            Quaternion facing = Quaternion.LookRotation(p_direction, Vector3.up);
            Quaternion next = Quaternion.RotateTowards(
                _body.rotation, facing, _turnSpeed * Mathf.Max(0f, p_deltaTime));
            _body.MoveRotation(next);
        }

        private void OnValidate()
        {
            _body ??= GetComponentInParent<Rigidbody>();
        }
    }
}

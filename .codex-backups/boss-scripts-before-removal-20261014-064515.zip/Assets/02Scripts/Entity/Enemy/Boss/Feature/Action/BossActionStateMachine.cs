using UnityEngine;

namespace Alpha.Boss
{
    internal interface IBossActionState
    {
        void Enter();
        void Tick(float p_deltaTime);
        void Exit();
    }

    // 전투 가능 여부에 따라 대기, 추적, 공격 행동을 전환한다.
    public sealed class BossActionStateMachine
    {
        private readonly BossActionFlow _flow;
        private readonly BossIdleState _idle;
        private readonly BossChaseState _chase;
        private readonly BossAttackState _attack;
        private IBossActionState _current;

        internal BossCore Core => _flow.Core;
        internal bool IsAttackState => _current == _attack;

        public BossActionStateMachine(BossActionFlow p_flow)
        {
            _flow = p_flow;
            _idle = new BossIdleState(this);
            _chase = new BossChaseState(this);
            _attack = new BossAttackState(this);
            SetState(_idle);
        }

        public void Tick(float p_deltaTime)
        {
            if (Core == null)
                return;

            if (!_flow.CanAct)
            {
                ResetToIdle();
                return;
            }

            if (_current == _idle)
                SetState(_chase);

            _current?.Tick(p_deltaTime);
            // 완료 직후 Chase로 돌아와도 Attack5의 마지막 이동량을 적용한다.
            Core.Locomotion.ApplyPendingRootMotion(p_deltaTime);
        }

        public void ResetToIdle()
        {
            if (Core == null)
                return;

            SetState(_idle);
            Core.Locomotion.ClearPendingRootMotion();
        }

        internal void StartAttack(EBossAttackType p_type)
        {
            if (Core.CombatFlow.TryStartAttack(p_type))
                SetState(_attack);
        }

        internal void FinishAttack()
        {
            if (_current == _attack)
                SetState(_chase);
        }

        public void Dispose()
        {
            if (Core != null)
            {
                _current?.Exit();
                Core.Locomotion.ClearPendingRootMotion();
            }

            _current = null;
        }

        private void SetState(IBossActionState p_next)
        {
            if (_current == p_next)
                return;

            _current?.Exit();
            _current = p_next;
            _current?.Enter();
        }
    }

    // 연출 대기와 전투 불가 상태에서는 이동과 공격을 멈춘다.
    internal sealed class BossIdleState : IBossActionState
    {
        private readonly BossActionStateMachine _machine;

        public BossIdleState(BossActionStateMachine p_machine)
        {
            _machine = p_machine;
        }

        public void Enter()
        {
            _machine.Core.Locomotion.Stop();
            _machine.Core.Animation.PlayIdle();
        }

        public void Tick(float p_deltaTime) { }
        public void Exit() { }
    }

    // 대상까지 이동하고 공격 거리에서 Combat의 실행 가능 여부를 확인한다.
    internal sealed class BossChaseState : IBossActionState
    {
        private readonly BossActionStateMachine _machine;

        public BossChaseState(BossActionStateMachine p_machine)
        {
            _machine = p_machine;
        }

        public void Enter() { }

        public void Tick(float p_deltaTime)
        {
            BossCore core = _machine.Core;
            Transform target = core.Target;
            if (target == null)
                return;

            float distance = core.CombatFlow.GetTargetingDistance(
                target.position);
            if (core.CombatFlow.TrySelectAttack(distance,
                    out EBossAttackType attackType))
            {
                core.Locomotion.Stop();

                if (core.CombatFlow.CanStartAttack)
                {
                    _machine.StartAttack(attackType);
                    return;
                }

                core.Locomotion.RotateTowards(
                    target.position, p_deltaTime);
                core.Animation.PlayIdle();
                return;
            }

            core.Animation.PlayChase();
            core.Locomotion.MoveTowards(target.position, p_deltaTime);
        }

        public void Exit()
        {
            _machine.Core.Locomotion.Stop();
        }
    }

    // Combat가 공격을 끝내면 다시 추적 행동으로 돌아간다.
    internal sealed class BossAttackState : IBossActionState
    {
        private readonly BossActionStateMachine _machine;

        public BossAttackState(BossActionStateMachine p_machine)
        {
            _machine = p_machine;
        }

        public void Enter()
        {
            BossCombatFlow combat = _machine.Core.CombatFlow;
            combat.OnAttackFinished += HandleAttackFinished;
        }

        public void Tick(float p_deltaTime)
        {
            BossCombatFlow combat = _machine.Core.CombatFlow;
            combat.Tick(p_deltaTime);
            if (_machine.IsAttackState && !combat.IsAttacking)
                _machine.FinishAttack();
        }

        public void Exit()
        {
            BossCore core = _machine.Core;
            core.CombatFlow.OnAttackFinished -= HandleAttackFinished;
            core.CombatFlow.CancelAttack();
            core.Locomotion.Stop();
        }

        private void HandleAttackFinished()
        {
            _machine.FinishAttack();
        }
    }
}

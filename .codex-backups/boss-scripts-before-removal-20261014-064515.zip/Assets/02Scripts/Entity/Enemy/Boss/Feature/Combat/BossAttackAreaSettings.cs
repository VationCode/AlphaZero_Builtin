using System;
using UnityEngine;

namespace Alpha.Boss
{
    public enum EBossAttackAreaShape
    {
        Sphere = 0,
        Box = 1,
        Sector = 2
    }

    // 공격의 범위 설정과 Scene Gizmo 미리보기에 쓰는 자세 계산을 제공한다.
    [Serializable]
    public sealed class BossAttackAreaSettings
    {
        [SerializeField] private Transform _origin;
        [SerializeField] private EBossAttackAreaShape _shape;
        [SerializeField] private Vector3 _localPosition;
        [SerializeField] private Vector3 _localEulerAngles;
        [SerializeField, Min(0.01f)] private float _width = 2f;
        [SerializeField, Min(0.01f)] private float _length = 2.5f;
        [SerializeField, Min(0.01f)] private float _radius = 2.5f;
        [SerializeField, Range(0.1f, 360f)] private float _angle = 90f;
        [SerializeField, Min(0.01f)] private float _height = 2f;

        public Transform Origin => _origin;
        public EBossAttackAreaShape Shape => _shape;
        public Vector3 LocalPosition => _localPosition;
        public Vector3 LocalEulerAngles => _localEulerAngles;
        public float Width => _width;
        public float Length => _length;
        public float Radius => _radius;
        public float Angle => _angle;
        public float Height => _height;

        public bool IsValid => _shape switch
        {
            EBossAttackAreaShape.Sphere => _radius > 0f,
            EBossAttackAreaShape.Box =>
                _width > 0f && _length > 0f && _height > 0f,
            EBossAttackAreaShape.Sector =>
                _radius > 0f && _angle > 0f && _height > 0f,
            _ => false
        };

        public BossAttackAreaSettings() { }

        public BossAttackAreaSettings(
            EBossAttackAreaShape p_shape,
            Vector3 p_localPosition,
            Vector3 p_localEulerAngles,
            float p_width,
            float p_length,
            float p_radius,
            float p_angle,
            float p_height)
        {
            _shape = p_shape;
            _localPosition = p_localPosition;
            _localEulerAngles = p_localEulerAngles;
            _width = p_width;
            _length = p_length;
            _radius = p_radius;
            _angle = p_angle;
            _height = p_height;
        }

        // Origin과 로컬 오프셋으로 미리보기의 월드 자세를 계산한다.
        public void GetWorldPose(
            Transform p_origin,
            out Vector3 p_position,
            out Quaternion p_rotation)
        {
            GetWorldPose(p_origin.position, p_origin.rotation,
                out p_position, out p_rotation);
        }

        public void GetWorldPose(
            Vector3 p_originPosition,
            Quaternion p_originRotation,
            out Vector3 p_position,
            out Quaternion p_rotation)
        {
            p_rotation = p_originRotation * Quaternion.Euler(_localEulerAngles);
            p_position = p_originPosition + p_originRotation * _localPosition;
        }

        public void Validate()
        {
            _width = Mathf.Max(0.01f, _width);
            _length = Mathf.Max(0.01f, _length);
            _radius = Mathf.Max(0.01f, _radius);
            _angle = Mathf.Clamp(_angle, 0.1f, 360f);
            _height = Mathf.Max(0.01f, _height);
        }
    }
}

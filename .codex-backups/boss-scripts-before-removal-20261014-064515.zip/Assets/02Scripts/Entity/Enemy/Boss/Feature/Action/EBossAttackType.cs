namespace Alpha.Boss
{
    // Animator의 공격 상태와 일대일로 대응한다.
    public enum EBossAttackType
    {
        Attack1 = 1,
        Attack2 = 2,
        Attack3 = 3,
        Attack4 = 4,
        Attack5 = 5,
        Attack6 = 6,
        Provokes = 7
    }
}
